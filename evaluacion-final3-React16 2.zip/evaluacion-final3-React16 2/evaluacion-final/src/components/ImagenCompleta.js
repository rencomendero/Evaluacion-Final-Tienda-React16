import React, { Component } from 'react'
import './ImagenCompleta.css';

import VistaPrincipal from './VistaPrincipal'

export default class ImagenCompleta extends Component {

  state = {
    boton: ''
  }

  nameProduct = '';
  stockProduct='';
  precioProduct='';
  urlProduct='';
  cantidadCarrito='';

UNSAFE_componentWillMount() {
  this.nameProduct = this.props.nameProduct;
  this.precioProduct = this.props.precioProduct;
  this.stockProduct = this.props.stockProduct;
  this.urlProduct = this.props.urlProduct;
  this.cantidadCarrito = this.props.cantidadCarrito;
}

atras(){
  this.setState ({boton:true});
}

  render () {
    if (this.state.boton) return <VistaPrincipal/>
    else
    return (
      <div id="body3">
      <nav className="white" id="nav">
        <div className="nav-wrapper">
          <a href="/#" id="brand-logo" className="brand-logo">Al mercado</a>
          <ul id="nav-mobile" className="right hide-on-med-and-down">
            <li><a id="a" href="/VistaPrincipal" className="material-icons">view_comfy</a></li>
            <li><a id="a" href="/#" className="material-icons">shopping_cart</a></li>
            <li><span className="badge2">{this.cantidadCarrito}</span></li>
            <li><a id="a" href="/#" className="material-icons">exit_to_app</a></li>
          </ul>
        </div>
      </nav>

        <div id="main" className="card">
          <div id="navbar" className="navbar row">
            <h2 id="h2" className="left">{this.nameProduct}</h2>
          </div>

          <div id="ccard" className="col s12 m12 l12 xl12">
            <div id="cardHorizontal" className="card horizontal">
              <div id="cardImage" className="card-image">
                <img id="img" src={this.urlProduct} alt="imagenProducto"/>
              </div>
              <div id="cardContent" className="card-content">
                <h4 className="price"><b>{this.precioProduct}</b></h4>
                <h5 className="stock"><b>{this.stockProduct}</b> unidades</h5>
              </div>
            </div>
          </div>
          <button id="boton" onClick={this.atras.bind(this)}>Atrás</button>
        </div>
        </div>
    )
  }
}
