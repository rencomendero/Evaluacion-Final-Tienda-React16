import React, { Component } from 'react'
import './VistaPrincipal.css';

import firebase from "firebase/app";
import "firebase/firestore";

import ImagenCompleta from './ImagenCompleta'

export default class VistaPrincipal extends Component {

  state = {
    cantidadCarrito: '',
    numberToCart: '',
    productos: [],
    nameToCart: '',
    boton: '',
    emptyCart: ''
  }

  cantidadRequerida='';
  cantCartObject='';
  numeroCarrito='';

  nameProduct='';
  stockProduct='';
  precioProduct='';
  urlProduct='';

  ver = e =>{
    this.nameProduct = (e.target.offsetParent.childNodes[1].textContent);
    this.precioProduct = (e.target.offsetParent.childNodes[3].textContent);
    this.stockProduct = (e.target.offsetParent.childNodes[4].textContent);
    this.urlProduct = (e.target.offsetParent.childNodes[0].currentSrc);
    this.setState ({boton:'ver'});
  }

  UNSAFE_componentWillMount() {
    this.getProducts();

    firebase.firestore().collection('DatosEvaluacion').doc('datos').get().then(datos =>{
      this.setState ({cantidadCarrito: datos.data().cantidad});
      if (this.state.cantidadCarrito>0) {
        this.setState ({emptyCart:true});
      }
    });
  }

  getProducts(){
    firebase.firestore().collection('ProductosEvaluacion').onSnapshot(querySnapshot => {
      const productos = [];
      querySnapshot.forEach((doc) => {
        productos.push({
          nombre: doc.data().nombre,
          precio: doc.data().precio,
          stock: doc.data().stock,
          url: doc.data().url,
          id: doc.id,
          cantidadRequerida: ''
        })
      })
      this.setState({productos});
    });
  }

  anadir = e =>{
    this.numeroCarrito = this.state.cantidadCarrito;
    this.numeroCarrito++;
    this.setState ({cantidadCarrito: this.numeroCarrito});
    this.cantCartObject = {
      cantidad: this.numeroCarrito
    }

    this.cantidadRequerida = e.target.offsetParent.childNodes[7].value;
    this.nameProduct = (e.target.offsetParent.childNodes[1].textContent);
    this.state.productos.forEach((doc) => {
      if (doc.nombre === this.nameProduct) {
        doc.cantidadRequerida = this.cantidadRequerida;

        firebase.firestore().collection('DatosEvaluacion').doc('carrito')
         .collection('productos').add(doc).then(res=>{
           firebase.firestore().collection('DatosEvaluacion').doc('datos')
           .update(this.cantCartObject).then(res=>{
               this.setState ({emptyCart:true});
             alert('Producto agregado al carrito');
           });
         });
      };
    })
  }

  render () {
    if (this.state.boton==='ver') return <ImagenCompleta
       nameProduct={this.nameProduct}
       precioProduct={this.precioProduct}
       stockProduct={this.stockProduct}
       urlProduct={this.urlProduct}
       cantidadCarrito={this.state.cantidadCarrito}/>
    else
    return (
      <div id="body2">
        <nav className="white" id="nav">
          <div className="nav-wrapper">
            <a href="/#" id="brand-logo" className="brand-logo">Al mercado</a>
            <ul id="nav-mobile" className="right hide-on-med-and-down">
              <li><a id="a" href="/VistaPrincipal" className="material-icons">view_comfy</a></li>
              <li><a id="a" href="/Carrito" className="material-icons">shopping_cart</a></li>
              {this.state.emptyCart && (<li><span className="badge2">{this.state.cantidadCarrito}</span></li> )}
              <li><a id="a" href="/#" className="material-icons">exit_to_app</a></li>
            </ul>
          </div>
        </nav>

        <div id="main" className="card">
           <div className="navbar">
             <h2 className="left">Catálogo de Productos</h2>
             <div className="right">
               <p id="preguntaBuscar">Que estás buscando?</p>
               <input id="busqueda" type="search" className="form-control" placeholder="Buscar producto"/>
             </div>
           </div>

           <div className="margen">
            <div id="fondoLista" className="row">
              <div>
              {this.state.productos.map((post, index) => {
                return <div key={index} className="for col s12 m6 l3 xl3">
                  <div id="tarjetaProductos" className="card">
                    <img id="imagen" src={post.url} alt="imagenProducto"/>
                    <p className="nameProduct flow-text center truncate">{post.nombre}</p>
                    <div className="divider"></div>
                    <p className="price">Precio: <b>S/. {post.precio.toFixed(2)}</b></p>
                    <p className="stock">Disponibilidad: <b>{post.stock}</b></p>
                    <button className="boton1 blue darken-3" onClick={this.ver}>Ver</button>
                    <button className="boton2 orange" onClick={this.anadir}>Añadir</button>
                    <input id="cantidadReservada" defaultValue="1" type="number" min="1" max={post.stock}/>
                  </div>
                </div>
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
    )
  }
}
