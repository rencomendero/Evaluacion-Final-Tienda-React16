import React, { Component } from 'react';
import './App.css';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import app from 'firebase/app';

import InicioSesion from './components/InicioSesion';
import VistaPrincipal from './components/VistaPrincipal';
import ImagenCompleta from './components/ImagenCompleta';
import Carrito from './components/Carrito';

const firebaseConfig = {
  apiKey: "AIzaSyBsTg-KklvBFTRCDWqaqtrxvcPXr1w_BPY",
  authDomain: "al-mercado-app.firebaseapp.com",
  databaseURL: "https://al-mercado-app.firebaseio.com",
  projectId: "al-mercado-app",
  storageBucket: "al-mercado-app.appspot.com",
  messagingSenderId: "680027008679",
  appId: "1:680027008679:web:b4c994b4cc377db3"
};

class App extends Component {

  UNSAFE_componentWillMount() {
    app.initializeApp(firebaseConfig);
  }


  render() {
    return <div>
      <Router>
        <Route exact path="/" render={() =>{
            return <div>
              <InicioSesion/>
            </div>
          }}>
        </Route>
        <Route exact path="/VistaPrincipal" render={() =>{
            return <div>
              <VistaPrincipal/>
            </div>
          }}>
        </Route>
        <Route exact path="/ImagenCompleta" render={() =>{
            return <div>
              <ImagenCompleta/>
            </div>
          }}>
        </Route>
        <Route exact path="/Carrito" render={() =>{
            return <div>
              <Carrito/>
            </div>
          }}>
        </Route>

      </Router>
    </div>
  }
}

export default App;
