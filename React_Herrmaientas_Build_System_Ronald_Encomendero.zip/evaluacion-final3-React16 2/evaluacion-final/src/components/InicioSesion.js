import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';
import "firebase/auth";
import firebase from "firebase/app";

import './InicioSesion.css';

export default class InicioSesion extends Component {

  UNSAFE_componentWillMount() {
    firebase.auth().signOut();
  }

  state = {
    user: '',
    password: '',
    redirect: false
  }

  onSubmit = (e) => {
    e.preventDefault();
      firebase.auth().signInWithEmailAndPassword(this.state.user, this.state.password).then((user)=>{
        alert('Ingreso exitoso');
        this.setState ({redirect: true});
      })
      .catch(function(error){
        alert('Usuario NO REGISTRADO');
      });
  }

  onChange = e =>{
    this.setState({
      [e.target.name]: e.target.value
    })
  }

  render() {
    if (this.state.redirect) return <Redirect to='VistaPrincipal'/>;
    else
    return (
        <div id="body">
          <div className="centrado">
            <h3 className="titulo">Inicia Sesión</h3>
            <form onSubmit={this.onSubmit}>
              <label id="tit">Correo electrónico:</label>
              <div className="form-group">
                <input name="user" type="email" onChange={this.onChange} value={this.state.user} id="email-input" required pattern="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?"/>
                </div>
              <label id="tit">Contraseña:</label>
              <div>
                <input name="password" type="password" onChange={this.onChange} value={this.state.password} id="password-input" required/>
              </div>
                <button id="botonEnviar" type="submit" className="btn green btn-success center-block">Ingresar</button>
            </form>
          </div>
        </div>
    )
  }
}
