import React, { Component } from 'react'
import './Carrito.css';

import firebase from "firebase/app";
import "firebase/firestore";
import { Redirect } from 'react-router-dom';

export default class Carrito extends Component {

  state = {
    cantidadCarrito: '',
    productos: [],
    boton: '',
    emptyCart: ''
  }

  subtotal = '';
  total = '';

  UNSAFE_componentWillMount() {
    this.getProducts();
    firebase.firestore().collection('DatosEvaluacion').doc('datos').get().then(datos =>{
      this.setState ({cantidadCarrito: datos.data().cantidad});
      if (this.state.cantidadCarrito>0) {
        this.setState ({emptyCart:true});
      } else {
        alert('Carrito de compras vacío');
        this.setState ({boton:true});
      }
    });
  }

  getProducts(){
    firebase.firestore().collection('DatosEvaluacion').doc("carrito").collection("productos").onSnapshot(res => {
      const productos = [];
      res.forEach((doc) => {
        productos.push({
          nombre: doc.data().nombre,
          precio: doc.data().precio,
          stock: doc.data().stock,
          url: doc.data().url,
          id: doc.data().id,
          idCarrito: doc.id,
          cantidadRequerida: doc.data().cantidadRequerida
        })
        this.subtotal = ((doc.data().precio)*(doc.data().cantidadRequerida));
        this.total = Number(this.total + this.subtotal);
      })
      this.setState({productos});
    });
  }

  atras(){
    this.setState ({boton:true});
  }

  pagar(){
    for (let i=0; i<this.state.cantidadCarrito; i++){
      firebase.firestore().collection('ProductosEvaluacion').doc(this.state.productos[i].id).get().then(recontra => {
         firebase.firestore().collection('ProductosEvaluacion').doc(this.state.productos[i].id)
         .update({stock: ((recontra.data().stock)-(this.state.productos[i].cantidadRequerida))});
        firebase.firestore().collection('DatosEvaluacion').doc('carrito').collection('productos').doc(this.state.productos[i].idCarrito).delete();
      });
    }
    firebase.firestore().collection('DatosEvaluacion').doc('datos').update({cantidad:0}).then(finish=>{
      alert('Compra realizada con éxito, se enviarán los productos muy pronto');
      this.setState ({boton:true});
    });

  }

  render(){
    if (this.state.boton) return <Redirect to='VistaPrincipal'/>;
    else
    return(
      <div id="body4">
        <nav className="white" id="nav1">
          <div className="nav-wrapper">
            <a href="/#" id="brand-logo" className="brand-logo">Al mercado</a>
            <ul id="nav-mobile" className="right hide-on-med-and-down">
              <li><a id="a" href="/VistaPrincipal" className="material-icons">view_comfy</a></li>
              <li><a id="a" href="/Carrito" className="material-icons">shopping_cart</a></li>
                {this.state.emptyCart && (<li><span className="badge2">{this.state.cantidadCarrito}</span></li> )}
              <li><a id="a" href="/#" className="material-icons">exit_to_app</a></li>
            </ul>
          </div>
        </nav>

        <div id="main2" className="card horizontal">
           <div id="navBar3" className="navbar">
             <h2 className="left">Carrito de Compras</h2>
           </div>

           <div id="margen4" className="margen">
             <div id="fondoLista" className="row">
                <div>
                  {this.state.productos.map((post, index) => {
                    return <div key={index} className="for col s12">
                              <div id="tarjetaProductos3" className="card horizontal">
                                <div id="cardImage3" className="card-image">
                                  <img id="imagen4" src={post.url} alt="imagenProducto"/>
                                </div>

                                <div className="card-stacked">
                                  <div className="row">
                                    <p id="nameProduct" className="nameProduct truncate">{post.nombre}</p>
                                    <p id="unidades" className="unidades">Unidades: <b>{post.cantidadRequerida}</b></p>
                                    <p id="precio" className="precio">Precio: <b>S/.{post.precio.toFixed(2)}</b></p>
                                  </div>
                                  <h6 id="h6"><b>Subtotal:  </b>S/.{(post.cantidadRequerida*post.precio).toFixed(2)}</h6>
                                </div>
                              </div>
                              <div className="divider"></div>
                            </div>
                          })}
                </div>
             </div>
           </div>

           <div className="panel-derecho">
             <p id="tot">Total:  <b>S/.{this.total}</b></p>
                <div className="botones">
                  <button className="cancelar" onClick={this.atras.bind(this)}> Cancelar </button>
                  <button className="cancelar" onClick={this.pagar.bind(this)} > Pagar </button>
                </div>
          </div>
        </div>
      </div>
    )
  }
}
